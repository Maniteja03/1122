package com.geminiai.imagedetection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImagedetectionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImagedetectionApplication.class, args);
	}

}
