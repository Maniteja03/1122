package com.geminiai.imagedetection.service;

import com.google.genai.Client;
import com.google.genai.types.Content;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;
import com.google.genai.types.Part;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.time.Duration;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class GeminiVisionService {

    private final Client client;
    private final String modelId = "gemini-2.0-flash";

    // === Tunables from application.properties (with safe defaults) ===
    @Value("${gemini.temperature:0.2}")
    private Float temperature;

    @Value("${gemini.topP:0.95}")
    private Float topP;

    @Value("${gemini.topK:32}")
    private Float topK;

    @Value("${gemini.maxOutputTokens:512}")
    private Integer maxOutputTokens;

    public GeminiVisionService(Client client) {
        this.client = client;
    }

    /** Object detection: model returns JSON because we set responseMimeType=application/json */
    public String detectObjects(byte[] imageBytes, String mimeType) {
        if (mimeType == null || mimeType.isBlank()) mimeType = "image/jpeg";

        String prompt = "Identify all objects in this image. " +
                "Return ONLY a JSON array with fields: label, confidence (0.0-1.0).";

        Content content = Content.fromParts(
                Part.fromText(prompt),
                Part.fromBytes(imageBytes, mimeType)
        );

        GenerateContentResponse resp = callWithRetry(content, defaultCfg());
        return extractJson(resp);
    }

    /** Extract printed/overlay timestamp and RegId if present */
    public String extractTimestamp(byte[] imageBytes, String mimeType) {
        if (mimeType == null || mimeType.isBlank()) mimeType = "image/jpeg";

        byte[] cropped = safeCropTop(imageBytes, mimeType, 0.15);

        String prompt =
                "Read ONLY the visible on-frame date/time text at the top banner of this image (ignore EXIF). " +
                "If a RegId is present, capture it too. " +
                "Return ONLY JSON:\n" +
                "{\n" +
                "  \"timestamp_iso\": string|null,\n" +
                "  \"raw_text\": string|null,\n" +
                "  \"timezone\": string|null,\n" +
                "  \"reg_id\": string|null,\n" +
                "  \"confidence\": number,\n" +
                "  \"notes\": string\n" +
                "}";

        Content content = Content.fromParts(
                Part.fromText(prompt),
                Part.fromBytes(cropped != null ? cropped : imageBytes, mimeType)
        );

        GenerateContentResponse resp = callWithRetry(content, defaultCfg());
        String json = extractJson(resp);

        // fallback regex if response is not valid JSON
        if (json == null || json.isBlank() || !looksLikeJson(json)) {
            String fallback = parseOverlayLine(json);
            if (fallback != null) return fallback;
            return "{\"timestamp_iso\":null,\"raw_text\":null," +
                    "\"timezone\":null,\"reg_id\":null," +
                    "\"confidence\":0.0," +
                    "\"notes\":\"No readable overlay\"}";
        }

        return json.trim();
    }

    // Build config from externalized tunables
    private GenerateContentConfig defaultCfg() {
        GenerateContentConfig.Builder b = GenerateContentConfig.builder()
                .responseMimeType("application/json");

        if (temperature != null) b.temperature(temperature);
        if (topP != null)        b.topP(topP);
        if (topK != null && topK > 0f) b.topK(topK);
        if (maxOutputTokens != null && maxOutputTokens > 0) b.maxOutputTokens(maxOutputTokens);

        return b.build();
    }

    // --- regex fallback for lines like "2025-03-31T10:05:38 UTC   RegId: ...."
    private static final Pattern LINE_RE = Pattern.compile(
            "(?<dt>\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2})\\s*(?<tz>UTC|GMT)?"
                    + ".*?(?:RegId\\s*:\\s*(?<reg>[0-9a-fA-F\\-]{36}))?",
            Pattern.CASE_INSENSITIVE
    );

    private String parseOverlayLine(String raw) {
        if (raw == null) return null;
        Matcher m = LINE_RE.matcher(raw.replace('\n', ' ').trim());
        if (!m.find()) return null;

        String dt = m.group("dt");
        String tz = Optional.ofNullable(m.group("tz")).orElse(null);
        String reg = Optional.ofNullable(m.group("reg")).orElse(null);

        String iso = dt + "Z";
        String rawShown = dt + (tz != null ? " " + tz : "");

        return "{"
                + "\"timestamp_iso\":\"" + iso + "\","
                + "\"raw_text\":\"" + escape(rawShown) + "\","
                + "\"timezone\":" + (tz == null ? "null" : "\"" + tz + "\"") + ","
                + "\"reg_id\":" + (reg == null ? "null" : "\"" + reg + "\"") + ","
                + "\"confidence\":0.98,"
                + "\"notes\":\"Parsed by regex fallback\""
                + "}";
    }

    private static String escape(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    private boolean looksLikeJson(String s) {
        if (s == null) return false;
        String t = s.trim();
        return (t.startsWith("{") && t.endsWith("}")) || (t.startsWith("[") && t.endsWith("]"));
    }

    // --- crop top banner ---
    private byte[] safeCropTop(byte[] imageBytes, String mimeType, double topRatio) {
        try (ByteArrayInputStream in = new ByteArrayInputStream(imageBytes)) {
            BufferedImage img = ImageIO.read(in);
            if (img == null) return null;
            int h = img.getHeight();
            int w = img.getWidth();
            int cropH = Math.max(10, (int) Math.round(h * topRatio));
            BufferedImage sub = img.getSubimage(0, 0, w, Math.min(cropH, h));
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            ImageIO.write(sub, "png", out);
            return out.toByteArray();
        } catch (Exception ignore) {
            return null;
        }
    }

    // --- call with retry ---
    private GenerateContentResponse callWithRetry(Content content, GenerateContentConfig cfg) {
        int attempts = 0, max = 4;
        long baseMs = 400;
        RuntimeException last = null;
        while (attempts < max) {
            attempts++;
            try {
                return client.models.generateContent(modelId, content, cfg);
            } catch (RuntimeException ex) {
                String msg = String.valueOf(ex.getMessage()).toLowerCase();
                boolean retryable = msg.contains("503") || msg.contains("overload")
                        || msg.contains("temporar") || msg.contains("timeout")
                        || msg.contains("unavailable") || msg.contains("cancelled");
                if (!retryable || attempts >= max) {
                    last = ex;
                    break;
                }
                try {
                    long delay = (long) (baseMs * Math.pow(2, attempts - 1));
                    Thread.sleep(Math.min(delay, Duration.ofSeconds(5).toMillis()));
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw ex;
                }
            }
        }
        throw last != null ? last : new RuntimeException("Unknown model error");
    }

    /** Safe extractor: resp.text() is all we need for SDK 1.12.0 */
    private String extractJson(GenerateContentResponse resp) {
        if (resp == null) return "{}";
        String t = resp.text();
        return (t == null || t.isBlank()) ? "{}" : t.trim();
    }
}
