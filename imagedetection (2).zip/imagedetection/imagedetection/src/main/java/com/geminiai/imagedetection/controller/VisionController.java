package com.geminiai.imagedetection.controller;

import com.geminiai.imagedetection.service.GeminiVisionService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping(path = "/api", produces = MediaType.APPLICATION_JSON_VALUE)
public class VisionController {

    private final GeminiVisionService visionService;

    public VisionController(GeminiVisionService visionService) {
        this.visionService = visionService;
    }

    @PostMapping(value = "/detect", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> detect(@RequestParam("file") MultipartFile file) {
        try {
            if (file == null || file.isEmpty()) {
                return badRequest("file required");
            }
            String mimeType = file.getContentType();
            if (mimeType == null || mimeType.isBlank()) mimeType = "image/jpeg";

            String result = visionService.detectObjects(file.getBytes(), mimeType);
            return okJson(result);
        } catch (Exception e) {
            return serverError(e);
        }
    }

    @PostMapping(value = "/extract-timestamp", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<String> extractTimestamp(@RequestParam("file") MultipartFile file) {
        try {
            if (file == null || file.isEmpty()) {
                return badRequest("file required");
            }
            String mimeType = file.getContentType();
            if (mimeType == null || mimeType.isBlank()) mimeType = "image/jpeg";

            String result = visionService.extractTimestamp(file.getBytes(), mimeType);
            return okJson(result);
        } catch (Exception e) {
            return serverError(e);
        }
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return okJson("{\"status\":\"OK\"}");
    }

    // ---------- helpers ----------

    private ResponseEntity<String> okJson(String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return ResponseEntity
                .ok()
                .headers(headers)
                .body((body == null || body.isBlank()) ? "{}" : body.trim());
    }

    private ResponseEntity<String> badRequest(String msg) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .contentType(MediaType.APPLICATION_JSON)
                .body("{\"error\":\"" + escape(msg) + "\"}");
    }

    private ResponseEntity<String> serverError(Exception e) {
        String msg = (e.getMessage() == null || e.getMessage().isBlank())
                ? (e.getClass().getSimpleName() + " occurred")
                : e.getMessage();
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .contentType(MediaType.APPLICATION_JSON)
                .body("{\"error\":\"" + escape(msg) + "\"}");
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
